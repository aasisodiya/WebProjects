A Pen created at CodePen.io. You can find this one at http://codepen.io/kristenzirkler/pen/eDzIE.

 Reveals more information on hover


(Need to see if I can reduce html)